document.addEventListener('DOMContentLoaded', () => {
    const products = [
        { title: 'Огірки', description: 'Свіжі огірки', category: 'Овочі', price: 100, date: '2024-05-24' },
        { title: 'Апельсини', description: 'Солодкі апельсини без кісточок', category: 'Фрукти', price: 300, date: '2024-02-17' },
        { title: 'Переці', description: 'Дуже смачні червоні перці', category: 'Овочі', price: 150, date: '2024-03-18' },
        { title: 'Банани', description: 'Свіжі та солодкі банани з Еквадору', category: 'Фрукти', price: 200, date: '2024-02-25' },
        { title: 'Виноград', description: 'Кисло-солодкий виноград без кісточок', category: 'Ягоди', price: 250, date: '2023-04-01' },
        { title: 'Черешні', description: 'Дуже солодкі черешні', category: 'Ягоди', price: 400, date: '2023-07-18' },
 
    ];

    const categoryFilter = document.getElementById('categoryFilter');
    const searchTerm = document.getElementById('searchTerm');
    const sortOrder = document.getElementById('sortOrder');
    const productList = document.getElementById('productList');

    function displayProducts(filteredProducts) {
        productList.innerHTML = '';
        filteredProducts.forEach(product => {
            const card = document.createElement('div');
            card.className = 'product-card';
            card.innerHTML = `
                <h3>${product.title}</h3>
                <p>${product.description}</p>
                <p><strong>Категорія:</strong> ${product.category}</p>
                <p><strong>Ціна:</strong> ${product.price} грн</p>
                <p><strong>Дата додавання:</strong> ${product.date}</p>
            `;
            productList.appendChild(card);
        });
    }

    function filterAndSortProducts() {
        let filteredProducts = products;

        const category = categoryFilter.value;
        if (category) {
            filteredProducts = filteredProducts.filter(product => product.category === category);
        }

        const search = searchTerm.value.toLowerCase();
        if (search) {
            filteredProducts = filteredProducts.filter(product => product.title.toLowerCase().includes(search) || product.description.toLowerCase().includes(search));
        }

        const sort = sortOrder.value;
        filteredProducts.sort((a, b) => {
            if (sort === 'priceAsc') return a.price - b.price;
            if (sort === 'priceDesc') return b.price - a.price;
            if (sort === 'newest') return new Date(b.date) - new Date(a.date);
            if (sort === 'oldest') return new Date(a.date) - new Date(b.date);
        });

        displayProducts(filteredProducts);
    }

    categoryFilter.addEventListener('change', filterAndSortProducts);
    searchTerm.addEventListener('input', filterAndSortProducts);
    sortOrder.addEventListener('change', filterAndSortProducts);

    displayProducts(products);
});
